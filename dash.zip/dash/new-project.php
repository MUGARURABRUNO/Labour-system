
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Dantty Dev - client &amp; Client Dashboard ">
	<meta name="author" content="Bootlab">

	<title>Add New Project | Dantty Dev - client &amp; Client Dashboard</title>

	<link rel="canonical" href="https://appstack.bootlab.io/pages-sign-up.php" />
	<link rel="shortcut icon" href="img/favicon.ico">

	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">

	<!-- Choose your prefered color scheme -->
	<!-- <link href="css/light.css" rel="stylesheet"> -->
	<!-- <link href="css/dark.css" rel="stylesheet"> -->

	<!-- BEGIN SETTINGS -->
	<!-- Remove this after purchasing -->
	<link class="js-stylesheet" href="css/light.css" rel="stylesheet">
	<!-- <script src="js/settings.js"></script> -->
	<!-- END SETTINGS -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:2120269,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script><script async src="https://www.googletagmanager.com/gtag/js?id=G-Q3ZYEKLQ68"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Q3ZYEKLQ68');
</script></head>
<!--
  HOW TO USE: 
  data-theme: default (default), dark, light
  data-layout: fluid (default), boxed
  data-sidebar-position: left (default), right
  data-sidebar-behavior: sticky (default), fixed, compact
-->

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-behavior="sticky">
	<div class="main d-flex justify-content-center w-100">
		<main class="content d-flex p-0">
			<div class="container d-flex flex-column">
				<div class="row h-100">
					<div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
						<div class="d-table-cell align-middle">

							<div class="text-center mt-4">
								<h1 class="h2">Get started</h1>
								<p class="lead">
									Add new project to the database.
								</p>
							</div>

							<div class="card">
								<div class="card-body">
									<div class="m-sm-4">
										<form action="" method="Post" enctype="multipart/form-data">
											<div class="row">
											<div class="mb-3 col-md-6">
												<label class="form-label">Clients / Organisation Name</label>
												<input class="form-control form-control-lg" type="text" name="ClientName" required/>
											</div>
											<div class="mb-3 col-md-6">
												<label class="form-label"> Project Name</label>
												<select  class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="projectName" required>
													<option  value="WebSite">WebSite</option>
													<option value="Upgrade CRM Software">Upgrade CRM Software</option>
													<option value="Databases" >Databases</option>
													<option value="Graphics" >Graphics</option>
													<option value="Security" >Security</option>
													</select>
											</div>
                                            </div>
											<div class="row">
											<div class="mb-3 col-md-6">
												<label class="form-label"> Project Description</label>
												<textarea rows="2" class="form-control form-control-lg" id="inputBio"  name="projectdescription" placeholder="Describe your project" required></textarea>
											</div>
											<div class="mb-3 col-md-6">
												<label class="form-label">Start Date</label>
												<input class="form-control form-control-lg" type="date" name="startDate" required/>
											</div>
											</div>
											<div class="row">
											<div class="mb-3 col-md-6">
												<label class="form-label">End Date</label>
												<input class="form-control form-control-lg" type="date" name="endDate" required />
											</div>
											
											<div class="mb-3 col-md-6">
												<label class="form-label">zip pictures and anyother information in a single folder</label>
												<input class="form-control form-control-lg" type="file" name="zip" placeholder="zip pictures and anyother information in a single folder" />
											</div>
											</div>
											<div class="text-center mt-3">
												<button type="submit" name="project" class="btn btn-lg btn-primary">Add Project</button>
											</div>
											<div class="text-center mt-3">
												<a href="index.php" class="btn btn-lg btn-primary">Back</a>
											</div>
										</form>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</main>
	</div>

	<script src="js/app.js"></script>

</body>

</html>

<?php
include 'config.php';

if (isset($_POST['project'])) {


  $ClientName = $_POST['ClientName'];
  $projectName = $_POST['projectName'];
  $projectdescription=$_POST['projectdescription'];
  $startDate = $_POST['startDate'];
  $endDate = $_POST['endDate'];
  $status = $_POST['status'];
  $zip = $_POST['zip'];

  $sql_insert = "INSERT INTO projects(`ClientName`,`projectName`,`projectdescription`,`startDate`,`endDate`,`status`,`zip`) VALUES('$ClientName','$projectName','$projectdescription','$startDate','$endDate','$status','$zip')";
  $sql_query = mysqli_query($conn, $sql_insert);
  if ($sql_query == TRUE) {
    echo "successful";
    // header('location: pages-projects-list.php');
  } else {
    echo mysqli_error($conn);
  }
}
?>