<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Bootstrap 5 Admin &amp; Dashboard Template">
	<meta name="author" content="Bootlab">

	<title>Edit Page | AppStack - Admin &amp; Dashboard Template</title>

	<link rel="canonical" href="https://appstack.bootlab.io/project-edit-page.php" />
	<link rel="shortcut icon" href="img/favicon.ico">

	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">

	<!-- Choose your prefered color scheme -->
	<!-- <link href="css/light.css" rel="stylesheet"> -->
	<!-- <link href="css/dark.css" rel="stylesheet"> -->

	<!-- BEGIN SETTINGS -->
	<!-- Remove this after purchasing -->
	<link class="js-stylesheet" href="css/light.css" rel="stylesheet">
	
	<!-- END SETTINGS -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:2120269,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script><script async src="https://www.googletagmanager.com/gtag/js?id=G-Q3ZYEKLQ68"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Q3ZYEKLQ68');
</script></head>
<!--
  HOW TO USE: 
  data-theme: default (default), dark, light
  data-layout: fluid (default), boxed
  data-sidebar-position: left (default), right
  data-sidebar-behavior: sticky (default), fixed, compact
-->

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-behavior="sticky">
	<div class="main d-flex justify-content-center w-100">
		<main class="content d-flex p-0">
			<div class="container d-flex flex-column">
				<div class="row h-100">
					<div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
						<div class="d-table-cell align-middle">

							<div class="text-center mt-4">
								<h1 class="h2">GET STARTED</h1>
								<p class="lead">
									Edit Pages
								</p>
							</div>

							<div class="card">
								<div class="card-body">
									<div class="m-sm-4">
                                    <?php 
include 'config.php';


if (isset($_REQUEST['update'])){
// echo "updating successful";
  $projectId=$_REQUEST['update'];
  $sql_fetch="SELECT * FROM projects WHERE projectId='$projectId'";
  $sql_query=mysqli_query($conn, $sql_fetch);
  $rows=mysqli_fetch_assoc($sql_query);

if(isset($_POST['update-record'])){
   
    $projectId=$_POST['projectId'];
    $ClientName=$_POST['ClientName'];
	$projectName=$_POST['projectName'];
	$projectdescription=$_POST['projectdescription'];
	$startDate=$_POST['startDate'];
	$endDate=$_POST['endDate'];
	$percentage=$_POST['percentage'];
	$status=$_POST['status'];


	$sql_insert="UPDATE projects SET `projectId`='$projectId', `ClientName`='$ClientName', `projectName`='$projectName', `projectdescription`='$projectdescription', `startDate`='$startDate', `endDate`='$endDate', `percentage`='$percentage',`status`='$status' WHERE `projectId`='$projectId'";
	$sql_query=mysqli_query($conn,$sql_insert);
	if ($sql_query==TRUE) {
	  echo " Update successful";
	}else{
	  echo mysqli_error($conn);
	}
  }
  
	?>
<form action="" method="Post" enctype="multipart/form-data">
		                                <div class="row">
											<div class="mb-3 ">
												<label class="form-label">Project Id</label>
												<input class="form-control form-control-lg" type="text" value="<?php echo $rows['projectId']; ?>" name="projectId" required/>
											</div>
											<div class="mb-3 ">
												<label class="form-label">Clients / Organisation Name</label>
												<input class="form-control form-control-lg" type="text" value="<?php echo $rows['ClientName']; ?>" name="ClientName" required/>
											</div>
											<div class="mb-3 ">
												<label class="form-label"> Project Name</label>
												<select  class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" value="<?php echo $rows['projectName']; ?>" name="projectName" required>
													<option  value="WebSite">WebSite</option>
													<option value="Upgrade CRM Software">Upgrade CRM Software</option>
													<option value="Databases" >Databases</option>
													<option value="Graphics" >Graphics</option>
													<option value="Security" >Security</option>
													</select>
											</div>
											<div class="mb-3 ">
												<label class="form-label"> Project Description</label>
												<textarea rows="2" class="form-control form-control-lg" id="inputBio"  value="<?php echo $rows['projectdescription']; ?>" name="projectdescription" placeholder="Describe your project" required></textarea>
											</div>
											<div class="mb-3 ">
												<label class="form-label">Start Date</label>
												<input class="form-control form-control-lg" type="date" value="<?php echo $rows['startDate']; ?>" name="startDate" required/>
											</div>
											<div class="mb-3 ">
												<label class="form-label">End Date</label>
												<input class="form-control form-control-lg" type="date" value="<?php echo $rows['endDate']; ?>" name="endDate" required />
											</div>
											<div class="mb-3 ">
												<label class="form-label">Percentage</label>
												<input class="form-control form-control-lg" type="text" value="<?php echo $rows['percentage']; ?>" name="percentage" required />
											</div>
											<div class="mb-3 ">
												<label class="form-label">Status</label>
												<input class="form-control form-control-lg" type="text" value="<?php echo $rows['status']; ?>" name="status" required />
											</div>
											
											<div class="text-center mt-3">
												<button type="submit" name="update-record" class="btn btn-lg btn-primary">Update Project</button>
											</div>
											
										</form>


<?php
}

if (isset($_REQUEST['delete'])){
    $projectId=$_REQUEST['delete'];
    $sql_delete="DELETE FROM projects WHERE projectId='$projectId'";
    $sql_query=mysqli_query($conn, $sql_delete);
    if ($sql_query==TRUE){
      echo "Deleted successful";
    }else{
      echo mysqli_error($conn);
    }
  }

// retrieving code 
$sql_fetch="SELECT * FROM projects";
$sql_query=mysqli_query($conn, $sql_fetch);
?>
                                    <table id="datatables-dashboard-projects" class="table table-striped my-0">
							<thead>
								<tr>
									<th>Project Name</th>
                                    <th>Client Name</th>
									<th class="d-none d-xl-table-cell">Project Description</th>
									<th class="d-none d-xl-table-cell">Start Date</th>
									<th class="d-none d-xl-table-cell">End Date</th>
									<th>Status</th>
									<th class="d-none d-xl-table-cell">Percentage</th>
                                    <th class="d-none d-xl-table-cell">Delete</th>
                                    <th class="d-none d-xl-table-cell">Update</th>
									
								</tr>
							</thead>
							<tbody>

<?php 
while($rows=mysqli_fetch_assoc($sql_query)){
// echo $rows['Fname']."<br>";
?>
								<tr>
									<td><?php echo $rows['projectName']  ?></td>
                                    <td><?php echo $rows['ClientName']  ?></td>
									<td class="d-none d-xl-table-cell"><?php echo $rows['projectdescription']  ?></td>
									<td class="d-none d-xl-table-cell"><?php echo $rows['startDate']  ?></td>
									<td class="d-none d-xl-table-cell"><?php echo $rows['endDate']  ?></td>
									<td><span class="badge bg-success"><?php echo $rows['status']  ?></span></td>
									<td><span class="d-none d-xl-table-cell"><?php echo $rows['percentage']  ?></span></td>
									<td><a href="?delete=<?php echo $rows['projectId']?>">Delete</a></td>
                                    <td><a href="?update=<?php echo $rows['projectId']?>">Update</a></td>
								</tr>
								<?php 
} ?>
								
							</tbody>
						</table>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</main>
	</div>

	<script src="js/app.js"></script>

</body>

</html>