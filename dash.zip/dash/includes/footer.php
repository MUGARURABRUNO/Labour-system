<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="contact.php">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="contact.php">contact</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="terms.html">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="terms.html">Terms of Service</a>
								</li>
							</ul>
						</div>
						<div class="col-6 text-end">
							<p class="mb-0">
								&copy; 2022 - <a href="index.php" class="text-muted">Dantty Dev</a>
							</p>
						</div>
					</div>
				</div>
</footer>